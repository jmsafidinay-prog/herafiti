// Dans index.html ou main.js
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/service-worker.js')
      .then(reg => {
        console.log('Service Worker enregistré avec succès :', reg.scope);
      })
      .catch(error => {
        console.log('Échec de l\'enregistrement du Service Worker :', error);
      });
  });
}