import { Cantique, Event, News } from '../lib/supabase';

const DB_NAME = 'FihiranaOfflineDB';
const DB_VERSION = 1;

const STORES = {
  CANTIQUES: 'cantiques',
  EVENTS: 'events',
  NEWS: 'news',
  PENDING_CHANGES: 'pendingChanges'
};

export interface PendingChange {
  id: string;
  store: string;
  action: 'create' | 'update' | 'delete';
  data: any;
  timestamp: number;
}

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result);

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;

      if (!db.objectStoreNames.contains(STORES.CANTIQUES)) {
        const cantiqueStore = db.createObjectStore(STORES.CANTIQUES, { keyPath: 'id' });
        cantiqueStore.createIndex('number', 'number', { unique: false });
      }

      if (!db.objectStoreNames.contains(STORES.EVENTS)) {
        const eventStore = db.createObjectStore(STORES.EVENTS, { keyPath: 'id' });
        eventStore.createIndex('event_date', 'event_date', { unique: false });
      }

      if (!db.objectStoreNames.contains(STORES.NEWS)) {
        const newsStore = db.createObjectStore(STORES.NEWS, { keyPath: 'id' });
        newsStore.createIndex('published_date', 'published_date', { unique: false });
      }

      if (!db.objectStoreNames.contains(STORES.PENDING_CHANGES)) {
        const pendingStore = db.createObjectStore(STORES.PENDING_CHANGES, { keyPath: 'id' });
        pendingStore.createIndex('timestamp', 'timestamp', { unique: false });
      }
    };
  });
}

export async function saveToIndexedDB<T>(storeName: string, data: T[]): Promise<void> {
  const db = await openDB();
  const transaction = db.transaction(storeName, 'readwrite');
  const store = transaction.objectStore(storeName);

  await store.clear();

  for (const item of data) {
    await store.put(item);
  }

  return new Promise((resolve, reject) => {
    transaction.oncomplete = () => {
      db.close();
      resolve();
    };
    transaction.onerror = () => reject(transaction.error);
  });
}

export async function getFromIndexedDB<T>(storeName: string): Promise<T[]> {
  const db = await openDB();
  const transaction = db.transaction(storeName, 'readonly');
  const store = transaction.objectStore(storeName);

  return new Promise((resolve, reject) => {
    const request = store.getAll();
    request.onsuccess = () => {
      db.close();
      resolve(request.result);
    };
    request.onerror = () => {
      db.close();
      reject(request.error);
    };
  });
}

export async function savePendingChange(change: Omit<PendingChange, 'id' | 'timestamp'>): Promise<void> {
  const db = await openDB();
  const transaction = db.transaction(STORES.PENDING_CHANGES, 'readwrite');
  const store = transaction.objectStore(STORES.PENDING_CHANGES);

  const pendingChange: PendingChange = {
    ...change,
    id: `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
    timestamp: Date.now()
  };

  await store.put(pendingChange);

  return new Promise((resolve, reject) => {
    transaction.oncomplete = () => {
      db.close();
      resolve();
    };
    transaction.onerror = () => reject(transaction.error);
  });
}

export async function getPendingChanges(): Promise<PendingChange[]> {
  return getFromIndexedDB<PendingChange>(STORES.PENDING_CHANGES);
}

export async function deletePendingChange(id: string): Promise<void> {
  const db = await openDB();
  const transaction = db.transaction(STORES.PENDING_CHANGES, 'readwrite');
  const store = transaction.objectStore(STORES.PENDING_CHANGES);

  await store.delete(id);

  return new Promise((resolve, reject) => {
    transaction.oncomplete = () => {
      db.close();
      resolve();
    };
    transaction.onerror = () => reject(transaction.error);
  });
}

export async function clearAllPendingChanges(): Promise<void> {
  const db = await openDB();
  const transaction = db.transaction(STORES.PENDING_CHANGES, 'readwrite');
  const store = transaction.objectStore(STORES.PENDING_CHANGES);

  await store.clear();

  return new Promise((resolve, reject) => {
    transaction.oncomplete = () => {
      db.close();
      resolve();
    };
    transaction.onerror = () => reject(transaction.error);
  });
}

export { STORES };
