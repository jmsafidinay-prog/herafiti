import { Fragment } from 'react';
import { Event } from '../lib/supabase';
import { CalendarIcon, PlusIcon, TrashIcon, EditIcon } from './Icons';

const eventTypes = ["Fitsidihana", "fete", "inauguration", "conference", "autre"];

const eventTypeLabels: Record<string, string> = {
  Fitsidihana: "Fitsidihana fiangonana",
  fete: "Fête d'église",
  inauguration: "Inauguration",
  conference: "Conférence",
  autre: "Autre"
};

interface EventsManagerProps {
  events: Event[];
  isEditMode: boolean;
  onAdd: (event: Omit<Event, 'id' | 'created_at' | 'updated_at'>) => void;
  onUpdate: (id: string, event: Partial<Event>) => void;
  onDelete: (id: string) => void;
  onRequestEditMode: () => void;
}

export function EventsManager({ events, isEditMode, onAdd, onUpdate, onDelete, onRequestEditMode }: EventsManagerProps) {
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    event_type: eventTypes[0],
    event_date: '',
    location: ''
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (editingId) {
      await onUpdate(editingId, formData);
      setEditingId(null);
    } else {
      await onAdd(formData as any);
    }
    setFormData({ title: '', description: '', event_type: eventTypes[0], event_date: '', location: '' });
    setIsAdding(false);
  };

  const startEdit = (event: Event) => {
    setEditingId(event.id);
    setFormData({
      title: event.title,
      description: event.description || '',
      event_type: event.event_type,
      event_date: event.event_date,
      location: event.location || ''
    });
    setIsAdding(true);
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('fr-FR', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  return (
    <div className="w-full max-w-4xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-highlight">Fandaharam-potoana 2026</h2>
        {!isEditMode &&false&& (
          <button
            onClick={onRequestEditMode}
            className="px-4 py-2 rounded-xl bg-highlight text-white flex items-center gap-2 hover:opacity-90"
          >
            <EditIcon className="w-5 h-5" />
            Mode Édition
          </button>
        )}
        {isEditMode && !isAdding && (
          <button
            onClick={() => setIsAdding(true)}
            className="px-4 py-2 rounded-xl bg-highlight text-white flex items-center gap-2 hover:opacity-90"
          >
            <PlusIcon className="w-5 h-5" />
            Ajouter
          </button>
        )}
      </div>

      {isAdding && isEditMode && (
        <div className="mb-6 p-6 rounded-xl bg-card shadow-xl">
          <h3 className="text-xl font-bold mb-4 text-primary">
            {editingId ? 'Modifier l\'événement' : 'Nouvel événement'}
          </h3>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1 text-secondary">Titre (requis)</label>
              <input
                type="text"
                required
                value={formData.title}
                onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                className="w-full p-3 rounded-xl bg-main border border-border text-primary"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-1 text-secondary">Type</label>
              <select
                value={formData.event_type}
                onChange={(e) => setFormData(prev => ({ ...prev, event_type: e.target.value }))}
                className="w-full p-3 rounded-xl bg-main border border-border text-primary"
              >
                {eventTypes.map(type => (
                  <option key={type} value={type}>{eventTypeLabels[type]}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-1 text-secondary">Date (requis)</label>
              <input
                type="date"
                required
                value={formData.event_date}
                onChange={(e) => setFormData(prev => ({ ...prev, event_date: e.target.value }))}
                className="w-full p-3 rounded-xl bg-main border border-border text-primary"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-1 text-secondary">Lieu</label>
              <input
                type="text"
                value={formData.location}
                onChange={(e) => setFormData(prev => ({ ...prev, location: e.target.value }))}
                className="w-full p-3 rounded-xl bg-main border border-border text-primary"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-1 text-secondary">Description</label>
              <textarea
                value={formData.description}
                onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                rows={4}
                className="w-full p-3 rounded-xl bg-main border border-border text-primary resize-y"
              ></textarea>
            </div>

            <div className="flex gap-3">
              <button
                type="submit"
                className="flex-1 p-3 rounded-xl bg-highlight text-white font-bold hover:opacity-90"
              >
                {editingId ? 'Sauvegarder' : 'Ajouter'}
              </button>
              <button
                type="button"
                onClick={() => {
                  setIsAdding(false);
                  setEditingId(null);
                  setFormData({ title: '', description: '', event_type: eventTypes[0], event_date: '', location: '' });
                }}
                className="flex-1 p-3 rounded-xl bg-border text-secondary font-bold hover:opacity-90"
              >
                Annuler
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="space-y-4">
        {events.length === 0 ? (
          <p className="text-center py-10 text-secondary">Aucun événement programmé</p>
        ) : (
          events.map(event => (
            <div key={event.id} className="p-5 rounded-xl bg-card shadow-lg border border-white/5">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <CalendarIcon className="w-5 h-5 text-highlight flex-shrink-0" />
                    <h3 className="text-xl font-bold text-primary">{event.title}</h3>
                  </div>
                  <p className="text-sm text-secondary mb-2">
                    {formatDate(event.event_date)}
                  </p>
                  <span className="inline-block px-3 py-1 rounded-full text-xs font-medium bg-highlight text-white mb-3">
                    {eventTypeLabels[event.event_type]}
                  </span>
                  {event.location && (
                    <p className="text-sm text-secondary mb-2">
                      📍 {event.location}
                    </p>
                  )}
                  {event.description && (
                    <p className="text-primary mt-3 whitespace-pre-wrap">{event.description}</p>
                  )}
                </div>
                {isEditMode && (
                  <div className="flex gap-2 ml-4">
                    <button
                      onClick={() => startEdit(event)}
                      className="p-2 rounded-lg bg-highlight text-white hover:opacity-90"
                    >
                      <EditIcon className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => confirm('Supprimer cet événement ?') && onDelete(event.id)}
                      className="p-2 rounded-lg bg-danger text-white hover:opacity-90"
                    >
                      <TrashIcon className="w-4 h-4" />
                    </button>
                  </div>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

import { useState } from 'react';
