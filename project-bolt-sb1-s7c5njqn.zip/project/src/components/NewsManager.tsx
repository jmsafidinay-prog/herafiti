import { useState } from 'react';
import { News } from '../lib/supabase';
import { NewspaperIcon, PlusIcon, TrashIcon, EditIcon } from './Icons';

interface NewsManagerProps {
  news: News[];
  isEditMode: boolean;
  onAdd: (newsItem: Omit<News, 'id' | 'created_at' | 'updated_at' | 'published_date'>) => void;
  onUpdate: (id: string, newsItem: Partial<News>) => void;
  onDelete: (id: string) => void;
  onRequestEditMode: () => void;
}

export function NewsManager({ news, isEditMode, onAdd, onUpdate, onDelete, onRequestEditMode }: NewsManagerProps) {
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    title: '',
    content: '',
    author: ''
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (editingId) {
      await onUpdate(editingId, formData);
      setEditingId(null);
    } else {
      await onAdd(formData);
    }
    setFormData({ title: '', content: '', author: '' });
    setIsAdding(false);
  };

  const startEdit = (newsItem: News) => {
    setEditingId(newsItem.id);
    setFormData({
      title: newsItem.title,
      content: newsItem.content,
      author: newsItem.author || ''
    });
    setIsAdding(true);
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('fr-FR', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="w-full max-w-4xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-highlight">Vaovaom-piangonana</h2>
        {!isEditMode && false && (
          <button
            onClick={onRequestEditMode}
            className="px-4 py-2 rounded-xl bg-highlight text-white flex items-center gap-2 hover:opacity-90"
          >
            <EditIcon className="w-5 h-5" />
            Mode Édition
          </button>
        )}
        {isEditMode && !isAdding && (
          <button
            onClick={() => setIsAdding(true)}
            className="px-4 py-2 rounded-xl bg-highlight text-white flex items-center gap-2 hover:opacity-90"
          >
            <PlusIcon className="w-5 h-5" />
            Ajouter
          </button>
        )}
      </div>

      {isAdding && isEditMode && (
        <div className="mb-6 p-6 rounded-xl bg-card shadow-xl">
          <h3 className="text-xl font-bold mb-4 text-primary">
            {editingId ? 'Modifier la nouvelle' : 'Nouvelle annonce'}
          </h3>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1 text-secondary">Titre (requis)</label>
              <input
                type="text"
                required
                value={formData.title}
                onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                className="w-full p-3 rounded-xl bg-main border border-border text-primary"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-1 text-secondary">Auteur</label>
              <input
                type="text"
                value={formData.author}
                onChange={(e) => setFormData(prev => ({ ...prev, author: e.target.value }))}
                className="w-full p-3 rounded-xl bg-main border border-border text-primary"
                placeholder="Nom de l'auteur (optionnel)"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-1 text-secondary">Contenu (requis)</label>
              <textarea
                required
                value={formData.content}
                onChange={(e) => setFormData(prev => ({ ...prev, content: e.target.value }))}
                rows={8}
                className="w-full p-3 rounded-xl bg-main border border-border text-primary resize-y"
                placeholder="Entrez le contenu de la nouvelle ici..."
              ></textarea>
            </div>

            <div className="flex gap-3">
              <button
                type="submit"
                className="flex-1 p-3 rounded-xl bg-highlight text-white font-bold hover:opacity-90"
              >
                {editingId ? 'Sauvegarder' : 'Publier'}
              </button>
              <button
                type="button"
                onClick={() => {
                  setIsAdding(false);
                  setEditingId(null);
                  setFormData({ title: '', content: '', author: '' });
                }}
                className="flex-1 p-3 rounded-xl bg-border text-secondary font-bold hover:opacity-90"
              >
                Annuler
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="space-y-6">
        {news.length === 0 ? (
          <p className="text-center py-10 text-secondary">Aucune nouvelle publiée</p>
        ) : (
          news.map(newsItem => (
            <article key={newsItem.id} className="p-6 rounded-xl bg-card shadow-lg border border-white/5">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <NewspaperIcon className="w-5 h-5 text-highlight flex-shrink-0" />
                    <h3 className="text-2xl font-bold text-primary">{newsItem.title}</h3>
                  </div>
                  <div className="flex items-center gap-4 text-sm text-secondary">
                    <span>{formatDate(newsItem.published_date)}</span>
                    {newsItem.author && (
                      <>
                        <span>•</span>
                        <span>Par {newsItem.author}</span>
                      </>
                    )}
                  </div>
                </div>
                {isEditMode && (
                  <div className="flex gap-2 ml-4">
                    <button
                      onClick={() => startEdit(newsItem)}
                      className="p-2 rounded-lg bg-highlight text-white hover:opacity-90"
                    >
                      <EditIcon className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => confirm('Supprimer cette nouvelle ?') && onDelete(newsItem.id)}
                      className="p-2 rounded-lg bg-danger text-white hover:opacity-90"
                    >
                      <TrashIcon className="w-4 h-4" />
                    </button>
                  </div>
                )}
              </div>
              <div className="text-primary leading-relaxed whitespace-pre-wrap mt-4">
                {newsItem.content}
              </div>
            </article>
          ))
        )}
      </div>
    </div>
  );
}
