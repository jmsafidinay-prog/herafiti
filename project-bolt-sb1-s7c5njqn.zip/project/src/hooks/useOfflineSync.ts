import { useState, useEffect, useCallback, useRef } from 'react';
import { supabase } from '../lib/supabase';
import {
  saveToIndexedDB,
  getFromIndexedDB,
  savePendingChange,
  getPendingChanges,
  deletePendingChange,
  STORES
} from '../utils/offlineStorage';

export function useOfflineSync() {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [isSyncing, setIsSyncing] = useState(false);
  const syncTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const syncPendingChanges = useCallback(async () => {
    if (!navigator.onLine || isSyncing) return;

    setIsSyncing(true);
    console.log('[Sync] Début de la synchronisation');

    try {
      const pendingChanges = await getPendingChanges();

      if (pendingChanges.length === 0) {
        console.log('[Sync] Aucune modification en attente');
        setIsSyncing(false);
        return;
      }

      console.log(`[Sync] ${pendingChanges.length} modifications à synchroniser`);

      for (const change of pendingChanges) {
        try {
          switch (change.action) {
            case 'create':
              await supabase.from(change.store).insert([change.data]);
              break;
            case 'update':
              await supabase.from(change.store).update(change.data).eq('id', change.data.id);
              break;
            case 'delete':
              await supabase.from(change.store).delete().eq('id', change.data.id);
              break;
          }

          await deletePendingChange(change.id);
          console.log(`[Sync] Synchronisation réussie: ${change.action} sur ${change.store}`);
        } catch (error) {
          console.error(`[Sync] Erreur lors de la synchronisation:`, error);
        }
      }

      console.log('[Sync] Synchronisation terminée');
    } catch (error) {
      console.error('[Sync] Erreur globale de synchronisation:', error);
    } finally {
      setIsSyncing(false);
    }
  }, [isSyncing]);

  useEffect(() => {
    const handleOnline = () => {
      console.log('[Sync] Connexion rétablie');
      setIsOnline(true);

      if (syncTimeoutRef.current) {
        clearTimeout(syncTimeoutRef.current);
      }

      syncTimeoutRef.current = setTimeout(() => {
        syncPendingChanges();
      }, 1000);
    };

    const handleOffline = () => {
      console.log('[Sync] Connexion perdue');
      setIsOnline(false);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      if (syncTimeoutRef.current) {
        clearTimeout(syncTimeoutRef.current);
      }
    };
  }, [syncPendingChanges]);

  return {
    isOnline,
    isSyncing,
    syncPendingChanges
  };
}
