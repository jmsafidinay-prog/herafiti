import { useState, useEffect, useCallback, useMemo, Fragment } from 'react';
import { supabase, Cantique, Event, News } from './lib/supabase';
import { useLocalStorage } from './hooks/useLocalStorage';
import { useOfflineSync } from './hooks/useOfflineSync';
import { saveToIndexedDB, getFromIndexedDB, savePendingChange, STORES } from './utils/offlineStorage';
import {
  MenuIcon, XIcon, MusicIcon, StarIcon, InfoIcon,
  SunIcon, MoonIcon, ArrowLeftIcon, ZoomInIcon, ZoomOutIcon, EditIcon,
  CalendarIcon, NewspaperIcon, PlusIcon, TrashIcon
} from './components/Icons';
import { EventsManager } from './components/EventsManager';
import { NewsManager } from './components/NewsManager';

const themes = ["Fanoloran-tena sy fibebahana", "Fianinana Kristianina", "Fiderana an'Andriamanitra", "Fisaorana an'Andriamanitra", "Mpivahiny", "Ny ankizy sy noely", "Ny Fanahy Masina", "Ny fahatanorana", "Ny fiantsoan'ny Tompo", "Ny finonana", "Ny tenin'Andriamanitra"];
const keys = ["Do", "Do#", "Ré", "Ré#", "Mi", "Fa", "Fa#", "Sol", "Sol#", "La", "La#", "Si"];
const rhythms = ["Miadana", "Manentanentana", "Mihetsiketsika"];

const ZOOM_STEP = 0.1;
const MIN_ZOOM = 0.8;
const MAX_ZOOM = 2.0;
const SECRET_PIN = '369586';

const eventTypes = ["Fitsidihana fiangonana", "Fetim-piangonana", "Fitokanana fiangonana", "Fifadian-kanina", "Fety"];

type View = 'list' | 'read' | 'pin_entry' | 'edit' | 'events' | 'events_edit' | 'news' | 'news_edit' | 'events_pin' | 'news_pin';

function App() {
  const [cantiques, setCantiques] = useState<Cantique[]>([]);
  const [favorites, setFavorites] = useLocalStorage<number[]>('cantiquesFavorites', []);
  const [theme, setTheme] = useLocalStorage('theme', 'dark');
  const [zoomLevel, setZoomLevel] = useLocalStorage('zoomLevel', 1.0);
  const [searchTerm, setSearchTerm] = useLocalStorage('lastSearchTerm', '');
  const [selectedTheme, setSelectedTheme] = useLocalStorage('theme-filter', '');
  const [selectedGadona, setSelectedGadona] = useLocalStorage('gadona-filter', '');
  const [selectedKey, setSelectedKey] = useLocalStorage('key-filter', '');
  const [view, setView] = useState<View>('list');
  const [selectedCantiqueNumber, setSelectedCantiqueNumber] = useLocalStorage<number | null>('lastViewedCantique', null);
  const [currentViewTitle, setCurrentViewTitle] = useState("");
  const [editingCantique, setEditingCantique] = useState<Cantique | null>(null);
  const [newCantique, setNewCantique] = useState({
    number: '',
    title: '',
    theme: themes[0],
    key: keys[0],
    gadona: rhythms[0],
    verses: ''
  });
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [pin, setPin] = useState('');
  const [pinError, setPinError] = useState('');
  const [loading, setLoading] = useState(true);

  const [events, setEvents] = useState<Event[]>([]);
  const [news, setNewsItems] = useState<News[]>([]);
  const [editingEvent, setEditingEvent] = useState<Event | null>(null);
  const [editingNews, setEditingNews] = useState<News | null>(null);
  const [newEvent, setNewEvent] = useState({
    title: '',
    description: '',
    event_type: eventTypes[0],
    event_date: '',
    location: ''
  });
  const [newNewsItem, setNewNewsItem] = useState({
    title: '',
    content: '',
    author: ''
  });

  const { isOnline, isSyncing, syncPendingChanges } = useOfflineSync();

  useEffect(() => {
    fetchCantiques();
    fetchEvents();
    fetchNews();
  }, []);

  async function fetchCantiques() {
    setLoading(true);

    if (isOnline) {
      try {
        const { data, error } = await supabase
          .from('cantiques')
          .select('*')
          .order('number', { ascending: true });

        if (error) {
          console.error('Error fetching cantiques:', error);
          const offlineData = await getFromIndexedDB<Cantique>(STORES.CANTIQUES);
          setCantiques(offlineData);
        } else {
          setCantiques(data || []);
          await saveToIndexedDB(STORES.CANTIQUES, data || []);
        }
      } catch (err) {
        console.error('Network error, loading from cache:', err);
        const offlineData = await getFromIndexedDB<Cantique>(STORES.CANTIQUES);
        setCantiques(offlineData);
      }
    } else {
      const offlineData = await getFromIndexedDB<Cantique>(STORES.CANTIQUES);
      setCantiques(offlineData);
    }

    setLoading(false);
  }

  async function fetchEvents() {
    if (isOnline) {
      try {
        const { data, error } = await supabase
          .from('events')
          .select('*')
          .order('event_date', { ascending: false });

        if (error) {
          console.error('Error fetching events:', error);
          const offlineData = await getFromIndexedDB<Event>(STORES.EVENTS);
          setEvents(offlineData);
        } else {
          setEvents(data || []);
          await saveToIndexedDB(STORES.EVENTS, data || []);
        }
      } catch (err) {
        const offlineData = await getFromIndexedDB<Event>(STORES.EVENTS);
        setEvents(offlineData);
      }
    } else {
      const offlineData = await getFromIndexedDB<Event>(STORES.EVENTS);
      setEvents(offlineData);
    }
  }

  async function fetchNews() {
    if (isOnline) {
      try {
        const { data, error } = await supabase
          .from('news')
          .select('*')
          .order('published_date', { ascending: false });

        if (error) {
          console.error('Error fetching news:', error);
          const offlineData = await getFromIndexedDB<News>(STORES.NEWS);
          setNewsItems(offlineData);
        } else {
          setNewsItems(data || []);
          await saveToIndexedDB(STORES.NEWS, data || []);
        }
      } catch (err) {
        const offlineData = await getFromIndexedDB<News>(STORES.NEWS);
        setNewsItems(offlineData);
      }
    } else {
      const offlineData = await getFromIndexedDB<News>(STORES.NEWS);
      setNewsItems(offlineData);
    }
  }

  useEffect(() => {
    const themeStyles = theme === 'dark' ? {
      '--color-bg-main': '#1f2937',
      '--color-bg-card': '#2a384f',
      '--color-text-primary': '#f3f4f6',
      '--color-text-secondary': '#9ca3af',
      '--color-highlight': '#3b82f6',
      '--color-border': '#4b5563',
      '--color-input-text': '#f3f4f6',
      '--color-danger': '#ef4444',
    } : {
      '--color-bg-main': '#fcfcfc',
      '--color-bg-card': '#ffffff',
      '--color-text-primary': '#341f1f',
      '--color-text-secondary': '#6b4c4c',
      '--color-highlight': '#a8721c',
      '--color-border': '#ddd',
      '--color-input-text': '#341f1f',
      '--color-danger': '#dc2626',
    };

    Object.entries(themeStyles).forEach(([key, value]) => {
      document.documentElement.style.setProperty(key, value);
    });
    document.documentElement.style.setProperty('--base-font-size', zoomLevel.toString());
  }, [theme, zoomLevel]);

  const filteredCantiques = useMemo(() => {
    const term = searchTerm.toLowerCase().trim();
    let filtered = currentViewTitle === "Mes Cantiques Favoris"
      ? cantiques.filter(c => favorites.includes(c.number))
      : cantiques;

    filtered = filtered.filter(cantique => {
      const textMatch = term === '' ||
        cantique.number.toString().includes(term) ||
        cantique.title.toLowerCase().includes(term) ||
        cantique.lyrics.toLowerCase().includes(term);
      const themeMatch = !selectedTheme || cantique.theme === selectedTheme;
      const keyMatch = !selectedKey || cantique.key === selectedKey;
      const gadonaMatch = !selectedGadona || cantique.gadona === selectedGadona;
      return textMatch && themeMatch && keyMatch && gadonaMatch;
    });

    return filtered.sort((a, b) => a.number - b.number);
  }, [searchTerm, selectedTheme, selectedKey, selectedGadona, currentViewTitle, favorites, cantiques]);

  const selectedCantique = useMemo(() => {
    return cantiques.find(c => c.number === selectedCantiqueNumber);
  }, [selectedCantiqueNumber, cantiques]);

  const goBack = useCallback(() => {
    setSelectedCantiqueNumber(null);
    localStorage.removeItem('lastViewedCantique');
    setCurrentViewTitle("");
    setView('list');
    setPin('');
    setPinError('');
    setEditingCantique(null);
    setNewCantique({ number: '', title: '', theme: themes[0], key: keys[0], gadona: rhythms[0], verses: '' });
  }, [setSelectedCantiqueNumber]);

  const showCantique = useCallback((number: number) => {
    setSelectedCantiqueNumber(number);
    setView('read');
  }, [setSelectedCantiqueNumber]);

  const toggleFavorite = useCallback(() => {
    if (selectedCantiqueNumber === null) return;
    setFavorites(prev =>
      prev.includes(selectedCantiqueNumber)
        ? prev.filter(n => n !== selectedCantiqueNumber)
        : [...prev, selectedCantiqueNumber]
    );
  }, [selectedCantiqueNumber, setFavorites]);

  const showFavorites = useCallback(() => {
    setIsSidebarOpen(false);
    setSearchTerm('');
    setSelectedTheme('');
    setSelectedKey('');
    setSelectedGadona('');
    setCurrentViewTitle("Mes Cantiques Favoris");
    setView('list');
  }, [setSearchTerm, setSelectedTheme, setSelectedKey, setSelectedGadona]);

  const handlePinSubmit = useCallback((e: React.FormEvent) => {
    e.preventDefault();
    setPinError('');
    if (pin === SECRET_PIN) {
      setView('edit');
      setPin('');
      setEditingCantique(null);
    } else {
      setPinError('Code PIN incorrect. Veuillez réessayer.');
      setPin('');
    }
  }, [pin]);

  const handleEventsPinSubmit = useCallback((e: React.FormEvent) => {
    e.preventDefault();
    setPinError('');
    if (pin === SECRET_PIN) {
      setView('events_edit');
      setPin('');
    } else {
      setPinError('Code PIN incorrect. Veuillez réessayer.');
      setPin('');
    }
  }, [pin]);

  const handleNewsPinSubmit = useCallback((e: React.FormEvent) => {
    e.preventDefault();
    setPinError('');
    if (pin === SECRET_PIN) {
      setView('news_edit');
      setPin('');
    } else {
      setPinError('Code PIN incorrect. Veuillez réessayer.');
      setPin('');
    }
  }, [pin]);

  const handleNewCantiqueChange = useCallback((e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setNewCantique(prev => ({
      ...prev,
      [name]: name === 'number' ? (value !== '' ? parseInt(value) : '') : value
    }));
  }, []);

  const handleAddCantique = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    if (newCantique.number === '' || !newCantique.title || !newCantique.verses) {
      alert('Veuillez remplir au moins le Numéro, le Titre et les Paroles.');
      return;
    }

    const cantiqueData = {
      number: newCantique.number,
      title: newCantique.title.trim(),
      lyrics: newCantique.verses.trim(),
      theme: newCantique.theme,
      key: newCantique.key,
      gadona: newCantique.gadona
    };

    if (isOnline) {
      const { error } = await supabase
        .from('cantiques')
        .insert([cantiqueData]);

      if (error) {
        alert(`Erreur: ${error.message}`);
        return;
      }
    } else {
      await savePendingChange({
        store: 'cantiques',
        action: 'create',
        data: { ...cantiqueData, id: `temp-${Date.now()}` }
      });
      alert('Mode hors ligne: La modification sera synchronisée lors de la reconnexion.');
    }

    await fetchCantiques();
    setNewCantique({ number: '', title: '', theme: themes[0], key: keys[0], gadona: rhythms[0], verses: '' });
    setView('list');
  }, [newCantique, isOnline]);

  const handleUpdateCantique = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingCantique || newCantique.number === '' || !newCantique.title || !newCantique.verses) {
      alert('Veuillez remplir tous les champs requis.');
      return;
    }

    const { error } = await supabase
      .from('cantiques')
      .update({
        number: newCantique.number,
        title: newCantique.title.trim(),
        lyrics: newCantique.verses.trim(),
        theme: newCantique.theme,
        key: newCantique.key,
        gadona: newCantique.gadona
      })
      .eq('id', editingCantique.id);

    if (error) {
      alert(`Erreur: ${error.message}`);
      return;
    }

    await fetchCantiques();
    setEditingCantique(null);
    setNewCantique({ number: '', title: '', theme: themes[0], key: keys[0], gadona: rhythms[0], verses: '' });
    setView('list');
  }, [editingCantique, newCantique]);

  const handleDeleteCantique = useCallback(async () => {
    if (!editingCantique || !confirm(`Êtes-vous sûr de vouloir supprimer le cantique #${editingCantique.number}: "${editingCantique.title}" ?`)) {
      return;
    }

    const { error } = await supabase
      .from('cantiques')
      .delete()
      .eq('id', editingCantique.id);

    if (error) {
      alert(`Erreur: ${error.message}`);
      return;
    }

    setFavorites(prev => prev.filter(n => n !== editingCantique.number));
    await fetchCantiques();
    setEditingCantique(null);
    setNewCantique({ number: '', title: '', theme: themes[0], key: keys[0], gadona: rhythms[0], verses: '' });
    setView('list');
  }, [editingCantique, setFavorites]);

  const selectCantiqueForEditing = useCallback((number: number) => {
    const cantique = cantiques.find(c => c.number === number);
    if (cantique) {
      setEditingCantique(cantique);
      setNewCantique({
        number: cantique.number.toString(),
        title: cantique.title,
        theme: cantique.theme,
        key: cantique.key,
        gadona: cantique.gadona,
        verses: cantique.lyrics
      });
    }
  }, [cantiques]);

  const handleAddEvent = useCallback(async (event: any) => {
    const { error } = await supabase.from('events').insert([event]);
    if (error) {
      alert(`Erreur: ${error.message}`);
      return;
    }
    await fetchEvents();
  }, []);

  const handleUpdateEvent = useCallback(async (id: string, event: Partial<Event>) => {
    const { error } = await supabase.from('events').update(event).eq('id', id);
    if (error) {
      alert(`Erreur: ${error.message}`);
      return;
    }
    await fetchEvents();
  }, []);

  const handleDeleteEvent = useCallback(async (id: string) => {
    const { error } = await supabase.from('events').delete().eq('id', id);
    if (error) {
      alert(`Erreur: ${error.message}`);
      return;
    }
    await fetchEvents();
  }, []);

  const handleAddNews = useCallback(async (newsItem: any) => {
    const { error } = await supabase.from('news').insert([newsItem]);
    if (error) {
      alert(`Erreur: ${error.message}`);
      return;
    }
    await fetchNews();
  }, []);

  const handleUpdateNews = useCallback(async (id: string, newsItem: Partial<News>) => {
    const { error } = await supabase.from('news').update(newsItem).eq('id', id);
    if (error) {
      alert(`Erreur: ${error.message}`);
      return;
    }
    await fetchNews();
  }, []);

  const handleDeleteNews = useCallback(async (id: string) => {
    const { error } = await supabase.from('news').delete().eq('id', id);
    if (error) {
      alert(`Erreur: ${error.message}`);
      return;
    }
    await fetchNews();
  }, []);

  const zoomIn = useCallback(() => {
    setZoomLevel(prev => Math.min(MAX_ZOOM, parseFloat((prev + ZOOM_STEP).toFixed(1))));
  }, [setZoomLevel]);

  const zoomOut = useCallback(() => {
    setZoomLevel(prev => Math.max(MIN_ZOOM, parseFloat((prev - ZOOM_STEP).toFixed(1))));
  }, [setZoomLevel]);

  const toggleTheme = useCallback(() => {
    setTheme(prev => prev === 'dark' ? 'light' : 'dark');
  }, [setTheme]);

  const renderHeader = () => {
    if (view === 'read') return null;

    return (
      <header className="bg-card mb-6 sticky top-0 z-10 flex items-center justify-between p-2 rounded-b-lg shadow-sm">
        <button
          onClick={() => view === 'list' ? setIsSidebarOpen(true) : goBack()}
          className="p-2 rounded-full cursor-pointer transition duration-300 shadow-md flex-shrink-0 mr-3 hover:opacity-80 bg-card border border-border"
        >
          {view === 'list' || view === 'pin_entry' || view === 'edit' ? (
            <MenuIcon className="text-highlight w-6 h-6" />
          ) : (
            <ArrowLeftIcon className="text-highlight w-6 h-6" />
          )}
        </button>

        <div className="flex-grow text-center min-w-0 mx-auto">
          <div className="flex items-center justify-center gap-2">
            <h1 className="header-main-title font-black truncate leading-tight text-highlight text-2xl sm:text-3xl">
              FIHIRANA
            </h1>
            {!isOnline && (
              <span className="text-xs px-2 py-1 rounded-full bg-yellow-500 text-white font-semibold">
                0net
              </span>
            )}
            {isSyncing && (
              <span className="text-xs px-2 py-1 rounded-full bg-blue-500 text-white font-semibold animate-pulse">
                Sync...
              </span>
            )}
          </div>
          <p className="text-xs sm:text-sm font-light truncate leading-none text-secondary">
            FIANGONANA HERIN' ANDRIAMANITRA HO FAMONJENA IZAO TONTOLO IZAO PENTEKOSTA
          </p>
          {currentViewTitle && (
            <p className="header-subtitle truncate text-secondary text-sm">
              {currentViewTitle}
            </p>
          )}
        </div>

        <div className="flex gap-2 ml-3 flex-shrink-0">
          <button onClick={zoomOut} className="p-2 rounded-full transition duration-300 shadow-md hover:opacity-80 bg-card text-highlight border border-border">
            <ZoomOutIcon className="w-6 h-6" />
          </button>
          <button onClick={zoomIn} className="p-2 rounded-full transition duration-300 shadow-md hover:opacity-80 bg-card text-highlight border border-border">
            <ZoomInIcon className="w-6 h-6" />
          </button>
          <button onClick={toggleTheme} className="p-2 rounded-full transition duration-300 shadow-md hover:opacity-80 bg-card text-highlight border border-border">
            {theme === 'dark' ? <SunIcon className="w-6 h-6" /> : <MoonIcon className="w-6 h-6" />}
          </button>
        </div>
      </header>
    );
  };

  const renderListView = () => (
    <Fragment>
      <div className="mb-6 p-4 rounded-xl shadow-xl bg-card">
        <div className="mb-4">
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => {
              setSearchTerm(e.target.value);
              if (currentViewTitle === "Mes Cantiques Favoris") {
                setCurrentViewTitle("");
              }
            }}
            placeholder="Rechercher par numéro, titre ou paroles..."
            className="w-full p-3 rounded-xl transition duration-150 bg-card border border-border text-primary"
          />
        </div>

        <div className="flex flex-col md:flex-row gap-3">
          <select
            value={selectedTheme}
            onChange={(e) => setSelectedTheme(e.target.value)}
            className="filter-select w-full md:w-1/3 p-3 rounded-xl transition duration-150 bg-card border border-border text-primary"
          >
            <option value="">-- Thème --</option>
            {themes.map(t => <option key={t} value={t}>{t}</option>)}
          </select>

          <select
            value={selectedGadona}
            onChange={(e) => setSelectedGadona(e.target.value)}
            className="filter-select w-full md:w-1/3 p-3 rounded-xl transition duration-150 bg-card border border-border text-primary"
          >
            <option value="">-- Rythme --</option>
            {rhythms.map(g => <option key={g} value={g}>{g}</option>)}
          </select>

          <select
            value={selectedKey}
            onChange={(e) => setSelectedKey(e.target.value)}
            className="filter-select w-full md:w-1/3 p-3 rounded-xl transition duration-150 bg-card border border-border text-primary"
          >
            <option value="">-- Tonalité --</option>
            {keys.map(k => <option key={k} value={k}>{k}</option>)}
          </select>
        </div>
      </div>

      <div className="flex flex-col gap-3 flex-grow overflow-y-auto pb-4">
        {loading ? (
          <div className="text-center py-20">
            <div className="inline-block animate-spin rounded-full h-12 w-12 border-4 border-highlight border-t-transparent"></div>
            <p className="mt-4 text-secondary">Chargement des cantiques...</p>
          </div>
        ) : filteredCantiques.length > 0 ? (
          filteredCantiques.map(c => (
            <div
              key={c.id}
              className="cantique-card flex items-center justify-between cursor-pointer p-4 rounded-xl shadow-lg transition duration-300 transform hover:scale-[1.01] bg-card border border-white/5"
              onClick={() => showCantique(c.number)}
            >
              <div className="flex items-center space-x-3 min-w-0">
                <span className="cantique-number font-bold mr-3 flex-shrink-0 text-highlight text-2xl">
                  {c.number}.
                </span>
                <MusicIcon className="w-5 h-5 flex-shrink-0 text-secondary" />
                <h3 className="cantique-list-title font-medium truncate flex-grow min-w-0 text-lg text-primary">
                  {c.title}
                </h3>
              </div>
              <span className="text-xs flex-shrink-0 ml-4 hidden sm:block text-secondary">
                {c.key} | {c.gadona}
              </span>
            </div>
          ))
        ) : (
          <p className="text-center mt-8 text-secondary">
            {currentViewTitle === "Mes Cantiques Favoris"
              ? "Vous n'avez pas encore de cantiques favoris."
              : "Aucun cantique trouvé."}
          </p>
        )}
      </div>
    </Fragment>
  );

  const renderReadView = () => {
    if (!selectedCantique) {
      goBack();
      return <div className="text-center mt-10 text-primary">Chargement...</div>;
    }

    const isCurrentlyFavorite = favorites.includes(selectedCantique.number);
    const versesHtml = selectedCantique.lyrics.split('\n\n').map((p, index) => {
      if (p.trim() === '') return null;
      return (
        <p key={index} className="mb-4 leading-relaxed whitespace-pre-wrap text-primary text-lg">
          {p.trim().split('\n').map((line, lineIndex) => (
            <Fragment key={lineIndex}>
              {line}
              <br />
            </Fragment>
          ))}
        </p>
      );
    }).filter(Boolean);

    return (
      <div className="flex flex-col flex-grow overflow-y-auto w-full">
        <div className="sticky top-0 z-20 p-3 w-full bg-main bg-opacity-95 backdrop-blur-sm shadow-md border-b border-border">
          <div className="flex justify-between items-center w-full max-w-4xl mx-auto px-4 sm:px-0">
            <button
              onClick={goBack}
              className="p-2 rounded-full cursor-pointer transition duration-300 hover:opacity-80 flex-shrink-0 bg-card border border-border"
            >
              <ArrowLeftIcon className="w-5 h-5 text-highlight" />
            </button>

            <div className="flex-grow text-center min-w-0 px-2 sm:px-4">
              <h2 className="font-bold truncate leading-tight text-primary text-lg">
                #{selectedCantique.number} - {selectedCantique.title}
              </h2>
            </div>

            <button
              onClick={toggleFavorite}
              className="p-2 rounded-full cursor-pointer transition duration-300 hover:opacity-80 flex-shrink-0 bg-card text-highlight border border-border"
            >
              <StarIcon filled={isCurrentlyFavorite} className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="p-4 md:p-8 pt-4 max-w-4xl mx-auto w-full flex-grow text-primary">
          <div className="text-center mb-8 pb-4 border-b border-border">
            <p className="text-sm font-semibold flex flex-wrap justify-center gap-x-3 text-secondary">
              Thème: <span className="font-bold text-primary">{selectedCantique.theme}</span>
              <span className="hidden sm:inline-block">|</span>
              Rythme: <span className="font-bold text-primary">{selectedCantique.gadona}</span>
              <span className="hidden sm:inline-block">|</span>
              Tonalité: <span className="font-bold text-primary">{selectedCantique.key}</span>
            </p>
          </div>

          {versesHtml.length > 0 ? versesHtml : <p className="text-secondary">Paroles non disponibles.</p>}

          <div className="h-20"></div>
        </div>
      </div>
    );
  };

  const renderPinEntryView = () => (
    <div className="flex flex-col items-center justify-center flex-grow overflow-hidden p-4">
      <div className="w-full max-w-sm p-8 rounded-xl shadow-2xl text-center bg-card text-primary">
        <EditIcon className="w-12 h-12 mx-auto mb-4 text-highlight" />
        <h2 className="text-2xl font-bold mb-4">Accès Édition</h2>
        <p className="mb-6 text-sm text-secondary">
          Veuillez entrer le code PIN de 6 chiffres pour accéder au formulaire d'ajout/modification de cantique.
        </p>

        <form onSubmit={handlePinSubmit}>
          <input
            type="password"
            name="pin"
            value={pin}
            onChange={(e) => setPin(e.target.value)}
            placeholder="______"
            maxLength={6}
            pattern="\d{6}"
            required
            className="w-full text-center p-3 mb-4 rounded-xl text-xl tracking-widest transition duration-150 font-mono bg-main border border-border text-primary"
          />
          {pinError && (
            <p className="text-sm mb-4 font-semibold text-danger">{pinError}</p>
          )}
          <button
            type="submit"
            className="w-full p-3 rounded-xl font-bold transition duration-300 shadow-lg hover:opacity-90 bg-highlight text-white"
          >
            Déverrouiller
          </button>
        </form>
        <button
          type="button"
          onClick={goBack}
          className="mt-4 text-sm hover:underline text-secondary"
        >
          Annuler et Retour à la Liste
        </button>
      </div>
    </div>
  );

  const renderEditorView = () => {
    const isEditing = editingCantique !== null;
    const title = isEditing ? `Modifier Cantique #${editingCantique.number}` : "Ajouter un Nouveau Cantique";
    const submitAction = isEditing ? handleUpdateCantique : handleAddCantique;
    const submitLabel = isEditing ? "Sauvegarder les Modifications" : "Ajouter le Cantique";
    const sortedCantiques = [...cantiques].sort((a, b) => a.number - b.number);

    const handleSelectToEdit = (e: React.ChangeEvent<HTMLSelectElement>) => {
      const numString = e.target.value;
      if (numString === '') {
        setEditingCantique(null);
        setNewCantique({ number: '', title: '', theme: themes[0], key: keys[0], gadona: rhythms[0], verses: '' });
      } else {
        const num = parseInt(numString);
        selectCantiqueForEditing(num);
      }
    };

    return (
      <div className="flex flex-col items-center w-full">
        <div className="max-w-3xl w-full p-6 rounded-xl shadow-2xl mb-12 bg-card">
          <h2 className="text-2xl font-bold mb-6 text-center text-highlight">{title}</h2>

          <div className="mb-6 border-b pb-4 border-border">
            <label className="block text-sm font-medium mb-2 text-secondary">
              Sélectionner pour Modifier ou Ajouter :
            </label>
            <select
              onChange={handleSelectToEdit}
              value={isEditing ? editingCantique.number.toString() : ''}
              className="filter-select w-full p-3 rounded-xl font-bold bg-main border border-border text-primary"
            >
              <option value="">-- Ajouter un nouveau cantique --</option>
              {sortedCantiques.map(c => (
                <option key={c.id} value={c.number.toString()}>
                  #{c.number} - {c.title}
                </option>
              ))}
            </select>
          </div>

          <form onSubmit={submitAction} className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1 text-secondary" htmlFor="number">
                Numéro (requis)
              </label>
              <input
                type="number"
                id="number"
                name="number"
                required
                value={newCantique.number}
                onChange={handleNewCantiqueChange}
                placeholder="Ex: 8 ou 0"
                min="0"
                className="w-full p-3 rounded-xl bg-main border border-border text-primary"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-1 text-secondary" htmlFor="title">
                Titre (requis)
              </label>
              <input
                type="text"
                id="title"
                name="title"
                required
                value={newCantique.title}
                onChange={handleNewCantiqueChange}
                placeholder="Ex: Mon Cœur Chante pour Toi"
                className="w-full p-3 rounded-xl bg-main border border-border text-primary"
              />
            </div>

            <div className="flex gap-4">
              <div className="flex-1">
                <label className="block text-sm font-medium mb-1 text-secondary" htmlFor="theme">
                  Thème
                </label>
                <select
                  id="theme"
                  name="theme"
                  value={newCantique.theme}
                  onChange={handleNewCantiqueChange}
                  className="filter-select w-full p-3 rounded-xl bg-main border border-border text-primary"
                >
                  {themes.map(t => <option key={t} value={t}>{t}</option>)}
                </select>
              </div>
              <div className="flex-1">
                <label className="block text-sm font-medium mb-1 text-secondary" htmlFor="key">
                  Tonalité
                </label>
                <select
                  id="key"
                  name="key"
                  value={newCantique.key}
                  onChange={handleNewCantiqueChange}
                  className="filter-select w-full p-3 rounded-xl bg-main border border-border text-primary"
                >
                  {keys.map(k => <option key={k} value={k}>{k}</option>)}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-1 text-secondary" htmlFor="gadona">
                Rythme
              </label>
              <select
                id="gadona"
                name="gadona"
                value={newCantique.gadona}
                onChange={handleNewCantiqueChange}
                className="filter-select w-full p-3 rounded-xl bg-main border border-border text-primary"
              >
                {rhythms.map(g => <option key={g} value={g}>{g}</option>)}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-1 text-secondary" htmlFor="verses">
                Paroles (requis)
              </label>
              <textarea
                id="verses"
                name="verses"
                required
                value={newCantique.verses}
                onChange={handleNewCantiqueChange}
                placeholder="Entrez les paroles complètes ici. Utilisez deux sauts de ligne pour séparer les strophes."
                rows={8}
                className="w-full p-3 rounded-xl resize-y bg-main border border-border text-primary"
              ></textarea>
            </div>

            <button
              type="submit"
              className="w-full p-3 rounded-xl font-bold transition duration-300 shadow-lg hover:opacity-90 mt-6 bg-highlight text-white"
            >
              {submitLabel}
            </button>

            {isEditing && (
              <button
                type="button"
                onClick={handleDeleteCantique}
                className="w-full p-3 rounded-xl font-bold transition duration-300 shadow-lg hover:bg-red-600 mt-2 bg-danger text-white"
              >
                Supprimer le Cantique
              </button>
            )}

            <button
              type="button"
              onClick={goBack}
              className="w-full p-3 rounded-xl font-bold transition duration-300 shadow-lg hover:opacity-90 mt-2 bg-border text-secondary"
            >
              Annuler et Retour
            </button>
          </form>
        </div>
      </div>
    );
  };

  const renderSidebar = () => (
    <Fragment>
      <div
        className={`fixed inset-0 bg-black bg-opacity-60 z-30 transition-opacity duration-300 ${
          isSidebarOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        }`}
        onClick={() => setIsSidebarOpen(false)}
      ></div>

      <div
        className={`fixed top-0 left-0 h-full z-40 overflow-y-auto p-4 flex flex-col w-[80%] max-w-[350px] transition-transform duration-300 bg-card ${
          isSidebarOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="flex justify-between items-center mb-6">
          <h3 className="cantique-list-title font-bold text-highlight text-lg">MENU</h3>
          <button
            onClick={() => setIsSidebarOpen(false)}
            className="p-2 rounded-full transition duration-300 hover:opacity-80 bg-card text-primary"
          >
            <XIcon className="w-6 h-6" />
          </button>
        </div>

        <div className="mb-6 flex flex-col gap-3">
          <h4 className="text-sm font-semibold mb-1 text-secondary">Navigation & Outils</h4>

          <button
            onClick={() => { setIsSidebarOpen(false); setCurrentViewTitle(""); setView('list'); }}
            className="w-full p-3 rounded-xl shadow-md transition duration-150 flex items-center justify-start hover:opacity-80 bg-card text-primary border border-border"
          >
            <MusicIcon className="w-6 h-6 mr-3 text-highlight" />
            Tous les Cantiques
          </button>

          <button
            onClick={showFavorites}
            className="w-full p-3 rounded-xl shadow-md transition duration-150 flex items-center justify-start hover:opacity-80 bg-card text-primary border border-border"
          >
            <StarIcon className="w-6 h-6 mr-3 text-highlight" />
            Liste des Favoris (<span className="font-bold ml-1">{favorites.length}</span>)
          </button>

          <button
            onClick={() => { setIsSidebarOpen(false); setView('events'); }}
            className="w-full p-3 rounded-xl shadow-md transition duration-150 flex items-center justify-start hover:opacity-80 bg-card text-primary border border-border"
          >
            <CalendarIcon className="w-6 h-6 mr-3 text-highlight" />
            Fandaharam-potoana 2026
          </button>

          <button
            onClick={() => { setIsSidebarOpen(false); setView('news'); }}
            className="w-full p-3 rounded-xl shadow-md transition duration-150 flex items-center justify-start hover:opacity-80 bg-card text-primary border border-border"
          >
            <NewspaperIcon className="w-6 h-6 mr-3 text-highlight" />
            Vaovaom-piangonana 
          </button>

          <button
            onClick={() => { setIsSidebarOpen(false); setView('pin_entry'); }}
            className="w-full p-3 rounded-xl shadow-md transition duration-150 flex items-center justify-start hover:opacity-80 bg-card text-primary border border-border"
          >
            <EditIcon className="w-6 h-6 mr-3 text-highlight" />
            Gestion des Cantiques 
          </button>

          <button
            onClick={() => { setIsModalOpen(true); setIsSidebarOpen(false); }}
            className="w-full p-3 rounded-xl shadow-md transition duration-150 flex items-center justify-start hover:opacity-80 bg-card text-primary border border-border"
          >
            <InfoIcon className="w-6 h-6 mr-3 text-highlight" />
            À Propos de l'application
          </button>
        </div>
      </div>
    </Fragment>
  );

  const renderAboutModal = () => {
    if (!isModalOpen) return null;

    return (
      <div
        className="fixed inset-0 bg-black bg-opacity-70 flex justify-center items-center z-50 transition-opacity duration-300 p-4"
        onClick={() => setIsModalOpen(false)}
      >
        <div
          className="w-full max-w-lg rounded-xl shadow-2xl flex flex-col max-h-[95vh] bg-card text-primary"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="flex justify-between items-center px-6 pt-6 pb-4 flex-shrink-0 border-b border-border">
            <h3 className="text-xl font-bold text-highlight">À Propos de l'Application</h3>
            <button
              onClick={() => setIsModalOpen(false)}
              className="p-2 rounded-full transition duration-200 hover:opacity-80 bg-card text-primary"
            >
              <XIcon className="w-6 h-6 hover:text-red-500" />
            </button>
          </div>

          <div className="text-sm p-6 overflow-y-auto flex-grow">
            <p className="font-bold text-lg mb-2 text-highlight">FIHIRANA</p>

            <p className="text-sm mb-4 text-secondary">
              Natonta tamin'ny fifohazam-panahy farany.
            </p>

            <p className="font-semibold text-base mb-2 text-primary">
              FIANGONANA HERIN' ANDRIAMANITRA HO FAMONJENA IZAO TONTOLO IZAO PENTEKOSTA
            </p>

            <p className="text-xs italic mb-4 text-secondary">
              Nalaina tamin'ny soratra masina sy ny filazantsaran'ny tantaran'i Jesosy Kristy izay nifantsika tamin'ny hazo fijaliana ho solom-panavotana ho an'ny mino.
            </p>

            <p className="font-bold text-base mt-4 text-highlight">
              Tanjon'ito application ito:
            </p>
            <p className="text-sm mb-3 text-secondary">
              Ito application ito dia fihirana natao ho fitaovana manamora sy mitondra fanampiana ho an'ny mpino rehetra sy ny fiderana an'Andriamanitra. Natao hanamafisana ny fifandraisanao amin'Andriamanitra sy hanentanana ny fanahy amin'ny alalan'ny teny fankaherezana.
            </p>

            <p className="text-sm mb-3 text-secondary">
              Ito fitaovana "numérique" ito dia tsy natao hanolo ny fihirana mahazatra izay vita boky sy voatonta fa natao kosa mba hifameno aminy satria "ny zavatra rehetra dia miara-miasa hahasoa izay tia an'Andriamanitra (...)" Romana 8 : 28
            </p>

            <div className="border-t pt-3 mt-3 text-center border-border">
              <p className="text-xs italic text-secondary">
                « Haleloia, fa tsara ny mihira ho an'Andriamanitsika, eny, mamy sady mendrika ny fiderana »
              </p>
              <p className="text-xs font-bold mt-1 mb-2 text-highlight">
                Salamo 147 : 1
              </p>
              <p className="text-xs font-bold text-highlight">
                Haleloia Amen
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const renderEventsPinEntry = () => (
    <div className="flex flex-col items-center justify-center flex-grow overflow-hidden p-4">
      <div className="w-full max-w-sm p-8 rounded-xl shadow-2xl text-center bg-card text-primary">
        <CalendarIcon className="w-12 h-12 mx-auto mb-4 text-highlight" />
        <h2 className="text-2xl font-bold mb-4">Accès Édition Agenda</h2>
        <p className="mb-6 text-sm text-secondary">
          Entrez le code PIN pour gérer les événements
        </p>
        <form onSubmit={handleEventsPinSubmit}>
          <input
            type="password"
            value={pin}
            onChange={(e) => setPin(e.target.value)}
            placeholder="______"
            maxLength={6}
            required
            className="w-full text-center p-3 mb-4 rounded-xl text-xl tracking-widest font-mono bg-main border border-border text-primary"
          />
          {pinError && <p className="text-sm mb-4 font-semibold text-danger">{pinError}</p>}
          <button type="submit" className="w-full p-3 rounded-xl font-bold bg-highlight text-white hover:opacity-90">
            Déverrouiller
          </button>
        </form>
        <button onClick={goBack} className="mt-4 text-sm hover:underline text-secondary">
          Retour
        </button>
      </div>
    </div>
  );

  const renderNewsPinEntry = () => (
    <div className="flex flex-col items-center justify-center flex-grow overflow-hidden p-4">
      <div className="w-full max-w-sm p-8 rounded-xl shadow-2xl text-center bg-card text-primary">
        <NewspaperIcon className="w-12 h-12 mx-auto mb-4 text-highlight" />
        <h2 className="text-2xl font-bold mb-4">Accès Édition Nouvelles</h2>
        <p className="mb-6 text-sm text-secondary">
          Entrez le code PIN pour gérer les nouvelles
        </p>
        <form onSubmit={handleNewsPinSubmit}>
          <input
            type="password"
            value={pin}
            onChange={(e) => setPin(e.target.value)}
            placeholder="______"
            maxLength={6}
            required
            className="w-full text-center p-3 mb-4 rounded-xl text-xl tracking-widest font-mono bg-main border border-border text-primary"
          />
          {pinError && <p className="text-sm mb-4 font-semibold text-danger">{pinError}</p>}
          <button type="submit" className="w-full p-3 rounded-xl font-bold bg-highlight text-white hover:opacity-90">
            Déverrouiller
          </button>
        </form>
        <button onClick={goBack} className="mt-4 text-sm hover:underline text-secondary">
          Retour
        </button>
      </div>
    </div>
  );

  let mainContent;
  switch (view) {
    case 'list':
      mainContent = renderListView();
      break;
    case 'read':
      mainContent = renderReadView();
      break;
    case 'pin_entry':
      mainContent = renderPinEntryView();
      break;
    case 'edit':
      mainContent = renderEditorView();
      break;
    case 'events':
      mainContent = (
        <EventsManager
          events={events}
          isEditMode={false}
          onAdd={handleAddEvent}
          onUpdate={handleUpdateEvent}
          onDelete={handleDeleteEvent}
          onRequestEditMode={() => setView('events_pin')}
        />
      );
      break;
    case 'events_edit':
      mainContent = (
        <EventsManager
          events={events}
          isEditMode={true}
          onAdd={handleAddEvent}
          onUpdate={handleUpdateEvent}
          onDelete={handleDeleteEvent}
          onRequestEditMode={() => setView('events_pin')}
        />
      );
      break;
    case 'events_pin':
      mainContent = renderEventsPinEntry();
      break;
    case 'news':
      mainContent = (
        <NewsManager
          news={news}
          isEditMode={false}
          onAdd={handleAddNews}
          onUpdate={handleUpdateNews}
          onDelete={handleDeleteNews}
          onRequestEditMode={() => setView('news_pin')}
        />
      );
      break;
    case 'news_edit':
      mainContent = (
        <NewsManager
          news={news}
          isEditMode={true}
          onAdd={handleAddNews}
          onUpdate={handleUpdateNews}
          onDelete={handleDeleteNews}
          onRequestEditMode={() => setView('news_pin')}
        />
      );
      break;
    case 'news_pin':
      mainContent = renderNewsPinEntry();
      break;
    default:
      mainContent = renderListView();
  }

  const headerElement = renderHeader();
  const containerClasses = view === 'read' || view === 'pin_entry' || view === 'events_pin' || view === 'news_pin'
    ? "min-h-screen flex flex-col"
    : "min-h-screen flex flex-col p-4 md:p-8";

  return (
    <div className={containerClasses}>
      {headerElement}
      <main className={`w-full mx-auto ${view === 'list' || view === 'read' ? 'flex-grow' : ''}`}>
        {mainContent}
      </main>
      {renderSidebar()}
      {renderAboutModal()}
    </div>
  );
}

export default App;
