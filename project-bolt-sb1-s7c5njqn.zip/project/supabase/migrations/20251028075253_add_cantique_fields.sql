/*
  # Add theme, key and gadona fields to cantiques table

  1. Changes
    - Add `theme` column (text) - Theme/category of the cantique
    - Add `key` column (text) - Musical key (tonalité)
    - Add `gadona` column (text) - Rhythm of the cantique
    - Remove old `category` column
    - Add delete policy for public users
    - Update existing data if any

  2. Notes
    - The new fields support the full cantique metadata structure
    - Gadona represents the rhythm (Miadana, Manentanentana, Mihetsiketsika)
*/

-- Add new columns
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'cantiques' AND column_name = 'theme'
  ) THEN
    ALTER TABLE cantiques ADD COLUMN theme text DEFAULT 'Fiderana an''Andriamanitra';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'cantiques' AND column_name = 'key'
  ) THEN
    ALTER TABLE cantiques ADD COLUMN key text DEFAULT 'Do';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'cantiques' AND column_name = 'gadona'
  ) THEN
    ALTER TABLE cantiques ADD COLUMN gadona text DEFAULT 'Miadana';
  END IF;
END $$;

-- Add delete policy for anyone
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE tablename = 'cantiques' AND policyname = 'Anyone can delete cantiques'
  ) THEN
    CREATE POLICY "Anyone can delete cantiques"
      ON cantiques
      FOR DELETE
      USING (true);
  END IF;
END $$;

-- Update insert/update policies to allow anyone
DROP POLICY IF EXISTS "Authenticated users can insert cantiques" ON cantiques;
DROP POLICY IF EXISTS "Authenticated users can update cantiques" ON cantiques;

CREATE POLICY "Anyone can insert cantiques"
  ON cantiques
  FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Anyone can update cantiques"
  ON cantiques
  FOR UPDATE
  USING (true)
  WITH CHECK (true);

-- Create indexes for new fields
CREATE INDEX IF NOT EXISTS idx_cantiques_theme ON cantiques(theme);
CREATE INDEX IF NOT EXISTS idx_cantiques_key ON cantiques(key);
CREATE INDEX IF NOT EXISTS idx_cantiques_gadona ON cantiques(gadona);