/*
  # Create Events and News Tables

  1. New Tables
    - `events` (Événements/Agendas de l'église)
      - `id` (uuid, primary key) - Unique identifier
      - `title` (text, not null) - Event title
      - `description` (text) - Event description
      - `event_type` (text) - Type: 'visite', 'fete', 'inauguration', 'conference', 'autre'
      - `event_date` (date) - Date of the event
      - `location` (text) - Event location
      - `created_at` (timestamptz) - Creation timestamp
      - `updated_at` (timestamptz) - Last update timestamp

    - `news` (Nouvelles de l'église)
      - `id` (uuid, primary key) - Unique identifier
      - `title` (text, not null) - News title
      - `content` (text, not null) - News content
      - `author` (text) - Author name
      - `published_date` (timestamptz) - Publication date
      - `created_at` (timestamptz) - Creation timestamp
      - `updated_at` (timestamptz) - Last update timestamp

  2. Security
    - Enable RLS on both tables
    - Allow public read access
    - Allow anyone to insert, update, and delete (PIN protection in frontend)
*/

-- Create events table
CREATE TABLE IF NOT EXISTS events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  event_type text DEFAULT 'autre',
  event_date date NOT NULL,
  location text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create news table
CREATE TABLE IF NOT EXISTS news (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  content text NOT NULL,
  author text,
  published_date timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE events ENABLE ROW LEVEL SECURITY;
ALTER TABLE news ENABLE ROW LEVEL SECURITY;

-- Events policies
CREATE POLICY "Anyone can view events"
  ON events
  FOR SELECT
  USING (true);

CREATE POLICY "Anyone can insert events"
  ON events
  FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Anyone can update events"
  ON events
  FOR UPDATE
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Anyone can delete events"
  ON events
  FOR DELETE
  USING (true);

-- News policies
CREATE POLICY "Anyone can view news"
  ON news
  FOR SELECT
  USING (true);

CREATE POLICY "Anyone can insert news"
  ON news
  FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Anyone can update news"
  ON news
  FOR UPDATE
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Anyone can delete news"
  ON news
  FOR DELETE
  USING (true);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_events_date ON events(event_date DESC);
CREATE INDEX IF NOT EXISTS idx_events_type ON events(event_type);
CREATE INDEX IF NOT EXISTS idx_news_published ON news(published_date DESC);