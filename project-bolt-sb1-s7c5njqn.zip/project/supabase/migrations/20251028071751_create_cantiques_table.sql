/*
  # Create Cantiques Application Schema

  1. New Tables
    - `cantiques`
      - `id` (uuid, primary key) - Unique identifier for each cantique
      - `title` (text, not null) - Title of the cantique
      - `number` (integer, unique) - Cantique number for reference
      - `lyrics` (text, not null) - Full lyrics of the cantique
      - `thème` (text) - Category (e.g., "Louange", "Adoration", "Prière")
      - `author` (text) - Author of the cantique if known
      - `created_at` (timestamptz) - Timestamp of creation
      - `updated_at` (timestamptz) - Timestamp of last update

  2. Security
    - Enable RLS on `cantiques` table
    - Add policy for public read access (cantiques are publicly viewable)
    - Add policy for authenticated users to insert/update cantiques
*/

CREATE TABLE IF NOT EXISTS cantiques (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  number integer UNIQUE,
  lyrics text NOT NULL,
  category text DEFAULT 'Louange',
  author text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE cantiques ENABLE ROW LEVEL SECURITY;

-- Allow everyone to read cantiques
CREATE POLICY "Anyone can view cantiques"
  ON cantiques
  FOR SELECT
  USING (true);

-- Allow authenticated users to insert cantiques
CREATE POLICY "Authenticated users can insert cantiques"
  ON cantiques
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Allow authenticated users to update cantiques
CREATE POLICY "Authenticated users can update cantiques"
  ON cantiques
  FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create index for faster searches
CREATE INDEX IF NOT EXISTS idx_cantiques_number ON cantiques(number);
CREATE INDEX IF NOT EXISTS idx_cantiques_category ON cantiques(category);
CREATE INDEX IF NOT EXISTS idx_cantiques_title ON cantiques(title);